#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
void PWM_SetCompare4(uint16_t Compare);

#endif
