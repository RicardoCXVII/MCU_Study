#include "stm32f10x.h" 
#define MIN_X 0  
#define MAX_X 250  
extern int openmv[7];//stm32������������
extern int16_t data1;
extern int16_t data2;
extern int16_t data3;
extern int16_t data4;
 
void Openmv_Receive_Data(int16_t data);
void Openmv_Data(void);
