#include "stm32f10x.h"                  // Device header

void Key_Init(void)
{
    // Enable the clocks for TIM4 and GPIOB
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);
    
    GPIO_InitTypeDef GPIO_InitStructure;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP; // Alternate function push-pull
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    TIM_InternalClockConfig(TIM4); // Select internal clock
    
    // Initialize time base unit
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStruct;
    TIM_TimeBaseInitStruct.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStruct.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStruct.TIM_Period = 100 - 1;       // ARR
    TIM_TimeBaseInitStruct.TIM_Prescaler = 720 - 1;    // PSC
    TIM_TimeBaseInitStruct.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseInitStruct);
    
    TIM_ClearFlag(TIM4, TIM_FLAG_Update);
    
    TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
    
    TIM_OCInitTypeDef TIM_OCInitStructure;
    TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High; // Active high
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0; // CCR
    
    TIM_OC4Init(TIM4, &TIM_OCInitStructure); // Using TIM4 Channel 4 which maps to PB9

    TIM_Cmd(TIM4, ENABLE); // Start the timer
}

void PWM_SetCompare4(uint16_t Compare)
{
    TIM_SetCompare4(TIM4, Compare); // Update the compare value for TIM4 Channel 4
}
