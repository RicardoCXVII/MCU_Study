
#ifndef _VOFA_USART_H_
#define _VOFA_USART_H_

#include  "motor_all_header.h"


// ͨ��
#define USART_MODULE                USART2
#define USART_MODULE_CLK            RCC_APB1Periph_USART2
#define USART_DR                    &(USART_MODULE->DR)

#define USART_DMA_TX_STREAM         DMA1_Stream6
#define USART_DMA_RX_STREAM         DMA1_Stream5

#define USART_DMA_TX_CHANNEL        DMA_Channel_4
#define USART_DMA_RX_CHANNEL        DMA_Channel_4

#define USART_DMA_TX_IRQn           DMA1_Stream6_IRQn
#define USART_DMA_RX_IRQn           DMA1_Stream5_IRQn

#define USART_DMA_TX_IRQHandler     DMA1_Stream6_IRQHandler
#define USART_DMA_RX_IRQHandler     DMA1_Stream5_IRQHandler

#define USART_DMA_TC_FLG            DMA_FLAG_TCIF6
#define USART_DMA_RC_FLG            DMA_FLAG_TCIF5

#define USART_TX_PIN                GPIO_Pin_2
#define USART_TX_GPIO_PORT          GPIOA
#define USART_TX_GPIO_CLK           RCC_AHB1Periph_GPIOA
#define USART_TX_SOURCE             GPIO_PinSource2
#define USART_TX_AF                 GPIO_AF_USART2

#define USART_RX_PIN                GPIO_Pin_3
#define USART_RX_GPIO_PORT          GPIOA
#define USART_RX_GPIO_CLK           RCC_AHB1Periph_GPIOA
#define USART_RX_SOURCE             GPIO_PinSource3
#define USART_RX_AF                 GPIO_AF_USART2

typedef union Resolve
{
    float    float_data;
    uint8_t  char_table[4];
}Resolve_Typedef;

extern Resolve_Typedef send_arr[4];
extern float speed_ref;

void usart_init(uint32_t baud_rate);
void usart_dma_send_config(float *buffer, uint32_t len);

#endif
