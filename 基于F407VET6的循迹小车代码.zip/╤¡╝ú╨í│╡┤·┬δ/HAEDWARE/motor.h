#ifndef __MOTOR_H
#define __MOTOR_H

void motor_Control(int side, int mode, int pwm_high, int pwm_low);
	
#endif
