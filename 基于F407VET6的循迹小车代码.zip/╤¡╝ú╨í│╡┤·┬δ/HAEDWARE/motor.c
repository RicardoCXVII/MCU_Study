#include "stm32f4xx.h"                  // Device header
#include "PWM.h"
#include "stm32f4xx_gpio.h"                  
#include "stm32f4xx_rcc.h"                  
#include "stm32f4xx_tim.h"   
#include "MOTOR.h"
#include "infrared.h"


/*��ʼ���˿ڵ�ƽ*/
void motor_Control(int side, int mode, int pwm_high, int pwm_low)
{
    if (side == 0) // �����
    {
        if (mode == 1)    //��ת
        {
            PWMLA_IN2 = pwm_high;
            PWMLA_IN1 = pwm_low;
            PWMLB_IN2 = pwm_high;
            PWMLB_IN1 = pwm_low;
        }
        else if (mode == 0)   //����
        {
            PWMLA_IN1 = pwm_high;
            PWMLA_IN2 = pwm_low;
            PWMLB_IN1 = pwm_high;
            PWMLB_IN2 = pwm_low;
        }
    }
    else if (side == 1) // �Ҳ���
    {
        if (mode == 1)    //��ת
        {
            PWMRA_IN1 = pwm_high;
            PWMRA_IN2 = pwm_low;
            PWMRB_IN1 = pwm_high;
            PWMRB_IN2 = pwm_low;
        }
        else if (mode == 0)    //����
        {           
            PWMRA_IN2 = pwm_high;
            PWMRA_IN1 = pwm_low;
            PWMRB_IN2 = pwm_high;
            PWMRB_IN1 = pwm_low;
        }
    }
}




//void Car_Control(int8_t Speed_1,int8_t Speed_2,int8_t Speed_3,int8_t Speed_4)//1234�ֱ��Ӧ��ǰ�֣��Һ��֣���ǰ�֣������
//{
//	if (Speed_1 >= 0)
//	{
//		GPIO_SetBits(GPIOD, GPIO_Pin_7);
//		GPIO_ResetBits(GPIOD, GPIO_Pin_6);
//		PWM_SetCompare1(Speed_1);
//	}
//	else
//	{
//		GPIO_ResetBits(GPIOD, GPIO_Pin_7);
//		GPIO_SetBits(GPIOD, GPIO_Pin_6);
//		PWM_SetCompare1(-Speed_1);
//		
//	}	
//		
//		if (Speed_2 >= 0)
//	{
//		GPIO_SetBits(GPIOD, GPIO_Pin_4);
//		GPIO_ResetBits(GPIOD, GPIO_Pin_5);
//		PWM_SetCompare2(Speed_2);
//	}
//	else
//	{
//		GPIO_ResetBits(GPIOD, GPIO_Pin_4);
//		GPIO_SetBits(GPIOD, GPIO_Pin_5);
//		PWM_SetCompare2(-Speed_2);
//	}
//	
//	
//	
//	
//	if (Speed_3 >= 0)
//	{
//		GPIO_SetBits(GPIOD, GPIO_Pin_10);
//		GPIO_ResetBits(GPIOD, GPIO_Pin_11);
//		PWM_SetCompare3(Speed_3);
//	}
//	else
//	{
//		GPIO_ResetBits(GPIOD, GPIO_Pin_10);
//		GPIO_SetBits(GPIOD, GPIO_Pin_11);
//		PWM_SetCompare3(-Speed_3);
//	}
//	
//	
//	
//	if (Speed_4 >= 0)
//	{
//		GPIO_SetBits(GPIOD, GPIO_Pin_9);
//		GPIO_ResetBits(GPIOD, GPIO_Pin_8);
//		PWM_SetCompare4(Speed_4);
//	}
//	else
//	{
//		GPIO_ResetBits(GPIOD, GPIO_Pin_9);
//		GPIO_SetBits(GPIOD, GPIO_Pin_8);
//		PWM_SetCompare4(-Speed_4);
//	}
//	
//}
