#ifndef __TIMER_H
#define __TIMER_H

void Timer_Init(uint16_t arr,uint16_t psc);
void TIM7_IRQHandler(void);
uint16_t Tim_Back(void);
#endif
