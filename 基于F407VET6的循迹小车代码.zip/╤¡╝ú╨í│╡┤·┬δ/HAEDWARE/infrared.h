#ifndef MOTOR_CONTROL_H
#define MOTOR_CONTROL_H

#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_tim.h"

// ��������
uint16_t Sensor_GetState(void);
void gray_check(void);
void Gray_Config(void);

#endif // MOTOR_CONTROL_H
