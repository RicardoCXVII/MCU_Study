#include "main.h"
#include "DELAY.h"
#include "OLED.H"
#include "PWM.H"
#include "stm32f4xx.h"                  // Device header
#include "USART_0.H"
#include "USART_1.h"
#include "KEY.h"
#include "Servo.h"
#include "ARM_ROBOT.h"
#include "PID_1.h"

static __IO uint32_t uwTimingDelay;
RCC_ClocksTypeDef RCC_Clocks;
static void Delay(__IO uint32_t nTime);
extern uint8_t Serial_RxPacket_1[];
uint16_t i;
float x, y1, y2;
PID_Controller panPID;  
PID_Controller tilt_PID_1;
PID_Controller tilt_PID_2;
float servo_rotation_value = 50.0;
float servo_pitch_value_1 = 120.0;
float servo_pitch_value_2 = 100.0;

uint8_t servo_rotation_direction=0;
uint8_t servo_pitch_direction_1=1;
uint8_t servo_pitch_direction_2=1;

/*
0                500
180              2500
*/

int main(void)
{	
	/*��ʼ������*/
	OLED_Init();
	USART_1_Init(115200);
	USART_0_Init(115200);
	Key_Init();
	PWM_Init(20000-1,84-1);
//	ARM_Refresh();
//	PID_Init(&panPID,  0.000005f, 0.0f, 0.1515f); // ˮƽ��PID������Ҫ����ʵ���������  
//	PID_Init(&tilt_PID_1, 1.0f, 0.0f, 0.0f); // ������PID������Ҫ����ʵ���������
//	PID_Init(&tilt_PID_2, 0.005f, 0.0f, 0.00f); // ������PID������Ҫ����ʵ���������	
//	//TARGET
//	PID_SetSetpoint(&panPID,80.0);
//	PID_SetSetpoint(&tilt_PID_1,120.0);
//	PID_SetSetpoint(&tilt_PID_2,80.0);

	/*���ڷ���*/
	while (1)
	{	
		Servo_SetAngle3(180.0);
//		Serial_Printf("%f, %d, %d\n", ReadServoAngle1(), 50, servo_rotation_value);
//		x=PID_Compute(&panPID, 50.0);  
//		y1=PID_Compute(&tilt_PID_1, ReadServoAngle2());
//		y2=PID_Compute(&tilt_PID_2, ReadServoAngle3());
//		if (!servo_rotation_direction) { // ���servo_rotation_directionΪfalse  
//        x = -x; // xȡ��  
//    }  
//    if (!servo_pitch_direction_1) { // ���servo_pitch_direction_1Ϊfalse  
//        y1 = y1; // yȡ��  
//    }  
//	if (!servo_pitch_direction_2) { // ���servo_pitch_direction_2Ϊfalse  
//        y2 = -y2; // yȡ��  
//    } 
//	
//    //����λ�ڣ�����X�ᣬY���ƶ� 
//    if (MIN_ANGLE_X < servo_rotation_value + x && servo_rotation_value + x < MAX_ANGLE_X) {  
//        servo_rotation_value += x; // ������תֵ  
//				Servo_SetAngle1(((servo_rotation_value-500)/ 2000.0f * 180)); // ����ˮƽ����  
//    }  
//    if (MIN_ANGLE_Y1 < servo_pitch_value_1 + y1 && servo_pitch_value_1 + y1 < MAX_ANGLE_Y1) { // ���踩��ֵҲ�����Ƶ���Ч��Χ���  
//        servo_pitch_value_1 += y1; // ���¸���ֵ  
//				Servo_SetAngle2(((servo_pitch_value_1-500)/ 2000.0f * 180)); // ����ˮƽ����  
//    }
//	if (MIN_ANGLE_Y2 < servo_pitch_value_2 + y2 && servo_pitch_value_2 + y2 < MAX_ANGLE_Y2) { // ���踩��ֵҲ�����Ƶ���Ч��Χ���  
//        servo_pitch_value_2 += y2; // ���¸���ֵ  
//				Servo_SetAngle2(servo_pitch_value_2); // ����ˮƽ����  
//    }
    Delay_ms(10);
	}                         
}                             
 

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
  */

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  if (uwTimingDelay != 0x00)
  { 
    uwTimingDelay--;
  }
}

#ifdef  USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */

//		Servo_SetAngle3(120.0);
//		for (uint16_t i = 0; i <= 3; i++)
//		{
//			Servo_SetAngle2((i * 10) + 120);
//			Delay_ms(500);
//		}
//		Servo_SetAngle2(160.0);
//		Delay_ms(50);
//		Servo_SetAngle3(180.0);
//		Delay_ms(500);
//		Servo_SetAngle2(100);


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
