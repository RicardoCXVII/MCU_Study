#include "PWM.h"
#include "PID.h"
#ifndef __SERVO_H
#define __SERVO_H
// ����Ƕȷ�Χ 
#define MIN_ANGLE_X 30.0f  
#define MAX_ANGLE_X 80.0f  
#define MIN_ANGLE_Y1 110.0f  //���
#define MAX_ANGLE_Y1 180.0f  //�  
#define MIN_ANGLE_Y2 70.0f  //����
#define MAX_ANGLE_Y2 180.0f  //����

void Servo_Init(void);
void Servo_SetAngle1(float Angle);
void Servo_SetAngle2(float Angle2);
void Servo_SetAngle3(float Angle3);
uint16_t PWM_GetCompare1();  
uint16_t PWM_GetCompare2();  
uint16_t PWM_GetCompare3();  
float ReadServoAngle1(void);    
float ReadServoAngle2(void);  
float ReadServoAngle3(void);  

#endif
