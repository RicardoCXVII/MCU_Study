#ifndef PWM_H
#define PWM_H

#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_rcc.h"
#include "stm32f4xx_tim.h"

// ���� PWM ͨ����
#define PWMLA_IN1  TIM4->CCR1
#define PWMLA_IN2  TIM4->CCR2
#define PWMLB_IN1  TIM4->CCR3
#define PWMLB_IN2  TIM4->CCR4
#define PWMRA_IN1  TIM5->CCR1
#define PWMRA_IN2  TIM5->CCR2
#define PWMRB_IN1  TIM5->CCR3
#define PWMRB_IN2  TIM5->CCR4

// ��������
void PWM_Init(uint32_t arr, uint32_t psc);
void PWM_SetCompare1(uint16_t Compare);
void PWM_SetCompare2(uint16_t Compare);
void PWM_SetCompare3(uint16_t Compare);

#endif // PWM_H
