#include "stm32f4xx.h"                  // Device header
#include "SCA.H"
#include "main.h"
#include "encoder.h"
#include "timer.h"
#include "main.h"
#include "DELAY.h"

extern int MyNum;
int oldTimValue = 0;
int deltaE;

/* �ٶȽ��㣺ʱ��ӱ�������ֵ -> �ٶ� */
float CalculateSpeed(uint8_t channelNum) 
	{
    int newEncoderValue, newTimValue,oldEncoderValue,overflowvalue,deltaT;
    int speed;
    
    // ��ȡ��ǰ��������ʱ��ֵ
    newEncoderValue = Read_Encoder(1);
    newTimValue = Tim_Back();
	overflowvalue = TIM_IRQHandler(TIM1);
	
	//ʱ���ֵ
    deltaT = (int) newTimValue;
	deltaE = (int) newEncoderValue + overflowvalue*1320;
		
    // �����ٶ�
	speed =(float) (newEncoderValue / (deltaT)); 
     
	
	//ʱ�丳���ʱ��
	oldTimValue = newTimValue;
	oldEncoderValue = newEncoderValue;

		
	//���ʱ��
	switch(channelNum)
	{                                            	                 
		case 1: TIM1->CNT = 0; break;	
		case 2: TIM2->CNT = 0; break;	
		case 3: TIM3->CNT = 0; break;
		case 4: TIM8->CNT = 0; break;
		default: break;
	}
	MyNum = 0;

	//�����ٶ�ֵ
    return speed;
}
