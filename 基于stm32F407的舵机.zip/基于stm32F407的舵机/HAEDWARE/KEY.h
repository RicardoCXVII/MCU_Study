#ifndef __TIMER_H
#define __TIMER_H

void Key_Init(void);
uint16_t KEY_number(void);



#endif
