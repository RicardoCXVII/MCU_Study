#ifndef __SCA_H
#define __SCA_H
#include "stm32f4xx.h"
#include "encoder.h"
#include "timer.h"

float CalculateSpeed(uint8_t channelNum);

#endif
