#ifndef __USART_0_H
#define __USART_0_H

#include <stdio.h>


extern uint8_t Serial_RxFlag_1;


void USART_1_Init(uint32_t bound);
void Serial_SendByte_1(uint8_t Byte);
//void Serial_SendArray(uint8_t *Array, uint16_t Length);
void Serial_SendString_1(char *String);
//void Serial_SendNumber(uint32_t Number, uint8_t Length);
void Serial_Printf_1(char *format, ...);

#endif

