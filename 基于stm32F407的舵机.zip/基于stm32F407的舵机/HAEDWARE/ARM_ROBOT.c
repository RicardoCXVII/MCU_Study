#include "main.h"
#include "Servo.h"

void ARM_Refresh(void)
{
	Servo_SetAngle1(50);
	Delay_ms(500);
	Servo_SetAngle3(150.0);
	Delay_ms(500);
	Servo_SetAngle2(140.0);
}