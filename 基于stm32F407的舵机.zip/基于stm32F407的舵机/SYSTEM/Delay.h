#ifndef __DELAY_H__
#define __DELAY_H__

#include "stm32f4xx.h"

void Delay_us(uint32_t xus);
void Delay_ms(uint32_t xms);
void Delay_s(uint32_t xs);

#endif /* __DELAY_H__ */
